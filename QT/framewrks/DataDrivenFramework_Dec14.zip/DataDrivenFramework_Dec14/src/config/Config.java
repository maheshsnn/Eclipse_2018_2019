package config;

public class Config {
	public static String url="http://demo.exaact.co/login.jsp";
	//public static String url="http://www.google.com";
	public static String browser="FF";
	public static String gmailurl="http://www.gmail.com";
	
	
		
	
}
