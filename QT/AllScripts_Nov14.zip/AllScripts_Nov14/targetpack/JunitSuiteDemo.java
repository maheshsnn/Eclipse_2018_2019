package targetpack;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ConfirmationDemo.class, FrameDemo.class, MultiFrames.class,
		WebElementsDemo.class })
public class JunitSuiteDemo {

}
