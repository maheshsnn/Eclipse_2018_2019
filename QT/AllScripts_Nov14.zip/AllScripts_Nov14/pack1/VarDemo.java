package pack1;

public class VarDemo {

	public static void main(String[] args) {
		int x=10,y=20;
		boolean b=true;
		double p=1.2;
		double q=2.4;
		String s="Hello";
		char ch='A';
		int a[]={1,2,3,4};
		System.out.println("Sum of x & y is:"+(x+y));
		System.out.println("Boolean var value is:"+b);
		System.out.println("Sum of p & q is"+(p+q));
		System.out.println("The value of string is:"+s);
		System.out.println("The value of char is:"+ch);
		System.out.println("Lenth of array is:"+a.length);
	}

}
