package pack1;

public class ForEachDemo {

	public static void main(String[] args) {
		int a[]={1,2,3,4,5};
		System.out.println("Array elements are:");
		for(int i:a)
		{
			System.out.println(i);
		}

	}

}
