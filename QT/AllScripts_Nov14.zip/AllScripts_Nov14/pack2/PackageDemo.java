package pack2;

import static pack1.P.show;

public class PackageDemo 
{
	public static void main(String[] args) {
		/*P b=new P(10,20);
		b.sub();
		b.sum();*/
		show();

	}

}
